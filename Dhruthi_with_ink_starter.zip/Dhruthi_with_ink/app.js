// Public reader. Connect Supabase using the instructions in SETUP.md.
const SUPABASE_URL = ''; // paste project URL
const SUPABASE_ANON_KEY = ''; // paste anon/public key (never service-role key)
const list = document.getElementById('poem-list');
async function loadPoems(){
 if(!SUPABASE_URL || !SUPABASE_ANON_KEY){return;}
 try{
  const res=await fetch(`${SUPABASE_URL}/rest/v1/poems?select=id,title,body,created_at&published=eq.true&order=created_at.desc`,{headers:{apikey:SUPABASE_ANON_KEY,Authorization:`Bearer ${SUPABASE_ANON_KEY}`}});
  if(!res.ok)throw new Error('Could not load poems');
  const poems=await res.json();
  if(!poems.length){list.innerHTML='<div class="empty">No poems published yet. Come back soon.</div>';return;}
  list.innerHTML=poems.map(p=>`<article class="poem-card" data-id="${escapeHtml(p.id)}"><div class="eyebrow">POEM</div><h3>${escapeHtml(p.title)}</h3><p>${new Date(p.created_at).toLocaleDateString()}</p></article>`).join('');
  list.querySelectorAll('.poem-card').forEach(card=>card.addEventListener('click',()=>openPoem(poems.find(p=>String(p.id)===card.dataset.id))));
 }catch(e){list.innerHTML='<div class="empty">Poems could not load. Please try again later.</div>';console.error(e);}
}
function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function openPoem(p){
 const overlay=document.createElement('div');overlay.className='reader';
 overlay.innerHTML=`<div class="reader-inner"><button class="close">← BACK TO POEMS</button><h2>${escapeHtml(p.title)}</h2><p class="date">${new Date(p.created_at).toLocaleDateString()}</p><div class="poem-text">${escapeHtml(p.body)}</div></div>`;
 overlay.querySelector('.close').onclick=()=>overlay.remove();document.body.appendChild(overlay);
}
loadPoems();